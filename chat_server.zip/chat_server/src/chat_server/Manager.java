package chat_server;

/**
 * Handle messages from clients.
 */
public class Manager {
    private static final NoClientException NO_CLIENT_E = new NoClientException();

    private final Database db = new Database();

    public void checkConnected(ClientHandle clientHandle) throws NoClientException {
        if (!clientHandle.isConnected()) throw NO_CLIENT_E;
    }

    public synchronized void close(ClientHandle clientHandle) {
        db.deleteUser(clientHandle.getUserName());
        clientHandle.getClientOut().close();
    }

    public synchronized void println(ClientHandle clientHandle, String msg) throws NoClientException {
        checkConnected(clientHandle);
        clientHandle.getClientOut().println(msg);
    }

    public void unknownCmd(ClientHandle clientHandle) throws NoClientException {
        println(clientHandle, "-ERR Unknown command");
    }

    /**
     * Handle "QUIT".
     * @param clientHandle
     * @throws NoClientException
     */
    public synchronized void quit(ClientHandle clientHandle) throws NoClientException {
        println(clientHandle, "+OK Goodbye");
    }

    /**
     * Handle "BCST".
     * @param clientHandle
     * @param doc
     * @throws NoClientException
     */
    public synchronized void sendBroadcast(ClientHandle clientHandle, String doc)
            throws NoClientException {
        checkConnected(clientHandle);
        for (User user: db.selectUserList()) {
            if (!user.getName().equals(clientHandle.getUserName())) {
                user.getClientOut().println("BCST " + clientHandle.getUserName() + " " + doc);
            }
            clientHandle.getClientOut().println("+OK BCST " + doc);
        }
    }

    /**
     * Handle "PM".
     * @param clientHandle
     * @param recipientUserName
     * @param doc
     * @throws NoClientException
     */
    public synchronized void sendPrivate(ClientHandle clientHandle, String recipientUserName, String doc)
            throws NoClientException {
        checkConnected(clientHandle);
        final User recipientUser = db.selectUser(recipientUserName);
        if (recipientUser == null) {
            clientHandle.getClientOut().println("-ERR no such user");
        } else {
            recipientUser.getClientOut().println("PM " + clientHandle.getUserName() + " " + doc);
            clientHandle.getClientOut().println("+OK PM");
        }
    }

    /**
     * Insert a new user into the database.
     * Called when the user is just logged into the server.
     * @param userName
     * @param clientOut
     * @return
     * @throws NoClientException
     */
    public synchronized ClientHandle insertUser(String userName, ClientOut clientOut)
            throws NoClientException {
        final User user = db.insertUser(userName, clientOut);
        if (user == null) {
            clientOut.println("-ERR user already logged in");
            return null;
        } else {
            clientOut.println("+OK HELO " + userName);
            return new ClientHandle(user, clientOut);
        }
    }

    /**
     * Handle "GET_USERS".
     * @param clientHandle
     * @throws NoClientException
     */
    public synchronized void sendUserList(ClientHandle clientHandle) throws NoClientException {
        checkConnected(clientHandle);
        final StringBuilder sb = new StringBuilder("+OK GET_USERS");
        for (User user: db.selectUserList()) {
            if (!user.getName().equals(clientHandle.getUserName())) {
                sb.append(" ");
                sb.append(user.getName());
            }
        }
        clientHandle.getClientOut().println(sb.toString());
    }

    /**
     * Handle "GET_GROUPS".
     * @param clientHandle
     * @throws NoClientException
     */
    public synchronized void sendGroupList(ClientHandle clientHandle) throws NoClientException {
        checkConnected(clientHandle);
        final StringBuilder sb = new StringBuilder("+OK GET_GROUPS");
        for (Group group: db.selectGroupList()) {
            sb.append(" ");
            sb.append(group.getName());
        }
        clientHandle.getClientOut().println(sb.toString());
    }

    /**
     * Handle "CREATE_GROUP".
     * @param clientHandle
     * @param groupName
     * @throws NoClientException
     */
    public synchronized void createGroup(ClientHandle clientHandle, String groupName)
            throws NoClientException {
        checkConnected(clientHandle);
        final Group group = db.insertGroup(groupName, clientHandle.getUser());
        if (group == null) {
            clientHandle.getClientOut().println("-ERR group \"" + groupName + "\" already exists");
        } else {
            clientHandle.getClientOut().println("+OK CREATE_GROUP " + groupName);
        }
    }

    /**
     * Handle "DISMISS_GROUP".
     * @param clientHandle
     * @param groupName
     * @throws NoClientException
     */
    public synchronized void dismissGroup(ClientHandle clientHandle, String groupName)
            throws NoClientException {
        checkConnected(clientHandle);
        switch (db.dismissGroup(groupName, clientHandle.getUserName())) {
            case OK:
                clientHandle.getClientOut().println("+OK DISMISS_GROUP " + groupName);
                break;
            case NO_GROUP:
                clientHandle.getClientOut().println("-ERR no such group");
                break;
            case USER_NOT_ADMIN:
                clientHandle.getClientOut().println(
                        "-ERR you are not the administrator of group \"" + groupName + "\"");
                break;
            default:
                clientHandle.getClientOut().println("-ERR internal error");
                System.out.println("internal error: DISMISS_GROUP, unknown DB result");
        }
    }

    /**
     * Handle "JOIN".
     * @param clientHandle
     * @param groupName
     * @throws NoClientException
     */
    public synchronized void userJoinGroup(ClientHandle clientHandle, String groupName)
            throws NoClientException {
        checkConnected(clientHandle);
        switch (db.userJoinGroup(groupName, clientHandle.getUserName())) {
            case OK:
                clientHandle.getClientOut().println("+OK JOIN " + groupName);
                break;
            case NO_USER:
                System.out.println("internal error: JOIN, no such user");
                break;
            case NO_GROUP:
                clientHandle.getClientOut().println("-ERR no such group");
                break;
            case USER_IN_GROUP:
                clientHandle.getClientOut().println("-ERR you are already in group \"" + groupName + "\"");
                break;
            case USER_BANNED:
                clientHandle.getClientOut().println("-ERR you were kicked from group \"" + groupName + "\"");
                break;
            default:
                clientHandle.getClientOut().println("-ERR internal error");
                System.out.println("internal error: JOIN, unknown DB result");
        }
    }

    /**
     * Handle "LEAVE".
     * @param clientHandle
     * @param groupName
     * @throws NoClientException
     */
    public void userLeaveGroup(ClientHandle clientHandle, String groupName)
            throws NoClientException {
        checkConnected(clientHandle);
        switch (db.userLeaveGroup(groupName, clientHandle.getUserName())) {
            case OK:
                clientHandle.getClientOut().println("+OK LEAVE " + groupName);
                break;
            case NO_USER:
                System.out.println("internal error: LEAVE, no such user");
                break;
            case NO_GROUP:
                clientHandle.getClientOut().println("-ERR no such group");
                break;
            case USER_NOT_IN_GROUP:
                clientHandle.getClientOut().println("-ERR you are not in group \"" + groupName + "\"");
                break;
            default:
                clientHandle.getClientOut().println("-ERR internal error");
                System.out.println("internal error: LEAVE, unknown DB result");
        }
    }

    /**
     * Handle "KICK".
     * @param clientHandle
     * @param groupName
     * @param userName
     * @throws NoClientException
     */
    public synchronized void kick(ClientHandle clientHandle, String groupName, String userName)
            throws NoClientException {
        checkConnected(clientHandle);
        switch (db.kickUser(groupName, clientHandle.getUserName(), userName)) {
            case OK:
                clientHandle.getClientOut().println("+OK KICK " + groupName + " " + userName);
                db.selectUser(userName).getClientOut().println("KICKED " + groupName);
                break;
            case NO_USER:
                clientHandle.getClientOut().println("-ERR no such user");
                break;
            case NO_GROUP:
                clientHandle.getClientOut().println("-ERR no such group");
                break;
            case USER_NOT_ADMIN:
                clientHandle.getClientOut().println(
                        "-ERR you are not the administrator of group \"" + groupName + "\"");
                break;
            case USER_NOT_IN_GROUP:
                clientHandle.getClientOut().println("-ERR user \""
                        + clientHandle.getUserName()
                        + "\" is not in group \"" + groupName + "\"");
                break;
            default:
                clientHandle.getClientOut().println("-ERR internal error");
                System.out.println("internal error: KICK, unknown DB result");
        }
    }

    /**
     * Handle "GROUP_MESSAGE".
     * @param clientHandle
     * @param groupName
     * @param doc
     * @throws NoClientException
     */
    public synchronized void sendToGroup(ClientHandle clientHandle, String groupName, String doc)
            throws NoClientException {
        checkConnected(clientHandle);
        final Group group = db.selectGroup(groupName);
        if (group == null) {
            clientHandle.getClientOut().println("-ERR no such group");
        } else {
            if (!group.isUserIn(clientHandle.getUserName())) {
                clientHandle.getClientOut().println(
                        "-ERR you are not in group \"" + groupName + "\"");
            } else {
                for (String userName: group.selectUserList()) {
                    if (!userName.equals(clientHandle.getUserName())) {
                        final User user = db.selectUser(userName);
                        if (user != null) {
                            user.getClientOut().println("GROUP_MESSAGE " + groupName
                                    + " " + clientHandle.getUserName()
                                    + " " + doc);
                        }
                    }
                    clientHandle.getClientOut().println("+OK GROUP_MESSAGE " + groupName
                            + " " + clientHandle.getUserName()
                            + " " + doc);
                }
            }
        }
    }

    /**
     * Handle "FILE_OFFER".
     * @param clientHandle
     * @param recipientUserName
     * @param params
     * @throws NoClientException
     */
    public void offerFile(ClientHandle clientHandle, String recipientUserName, String params)
            throws NoClientException {
        checkConnected(clientHandle);
        final User user = db.selectUser(recipientUserName);
        if (user == null) {
            clientHandle.getClientOut().println("-ERR no such user");
        } else {
            user.getClientOut().println("FILE_OFFER "
                    + clientHandle.getUserName() + " " + params);
            clientHandle.getClientOut().println("+OK FILE_OFFER");
        }
    }

    /**
     * Handle "FILE_ACCEPT".
     * @param clientHandle
     * @param senderUserName
     * @throws NoClientException
     */
    public synchronized void acceptFile(ClientHandle clientHandle, String senderUserName)
            throws NoClientException {
        checkConnected(clientHandle);
        final User user = db.selectUser(senderUserName);
        if (user == null) {
            clientHandle.getClientOut().println("-ERR no such user");
        } else {
            user.getClientOut().println("FILE_ACCEPT " + clientHandle.getUserName());
            clientHandle.getClientOut().println("+OK FILE_ACCEPT");
        }
    }

    /**
     * Handle "FILE_DATA".
     * @param clientHandle
     * @param recipientUserName
     * @param data
     * @throws NoClientException
     */
    public synchronized void sendFileData(ClientHandle clientHandle, String recipientUserName, String data)
            throws NoClientException {
        checkConnected(clientHandle);
        final User recipientUser = db.selectUser(recipientUserName);
        if (recipientUser == null) {
            clientHandle.getClientOut().println("-ERR no such user");
        } else {
            recipientUser.getClientOut().println("FILE_DATA " + clientHandle.getUserName() + " " + data);
            clientHandle.getClientOut().println("+OK FILE_DATA");
        }
    }

    /**
     * Handle "FILE_END".
     * @param clientHandle
     * @param recipientUserName
     * @throws NoClientException
     */
    public synchronized void sendFileEnd(ClientHandle clientHandle, String recipientUserName)
            throws NoClientException {
        checkConnected(clientHandle);
        final User recipientUser = db.selectUser(recipientUserName);
        if (recipientUser == null) {
            clientHandle.getClientOut().println("-ERR no such user");
        } else {
            recipientUser.getClientOut().println("FILE_END " + clientHandle.getUserName());
            clientHandle.getClientOut().println("+OK FILE_END");
        }
    }

    /**
     * Send "PING" to all clients.
     */
    public synchronized void sendPing() {
        for (User user: db.selectUserList()) {
            final ClientOut clientOut = user.getClientOut();
            try {
                clientOut.println("PING");
            } catch (NoClientException e) {
            }
            clientOut.setNotResponding(true);
        }
    }

    /**
     * Handle "PONG".
     * @param clientHandle
     * @throws NoClientException
     */
    public synchronized void pong(ClientHandle clientHandle) throws NoClientException {
        checkConnected(clientHandle);
        clientHandle.getClientOut().setNotResponding(false);
    }

    public synchronized void purgeNotResponding() {
        for (User user: db.selectUserList()) {
            final ClientOut clientOut = user.getClientOut();
            if (clientOut.isNotResponding()) {
                try {
                    clientOut.println("DSCN Pong timeout");
                    clientOut.close();
                } catch (NoClientException e) {
                }
            }
        }
    }
}
