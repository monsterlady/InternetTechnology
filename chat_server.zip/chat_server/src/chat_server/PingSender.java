package chat_server;

/**
 * Ping all clients with the period of {@code PING_TIME + RESPOND_TIME} ms.
 * Disconnect the clients that did not respond according to the protocol
 * in {@link #RESPOND_TIME} ms.
 */
public class PingSender implements Runnable {
    public static final int PING_TIME = 30000;
    public static final int RESPOND_TIME = 3000;

    private final Manager manager;

    public PingSender(Manager manager) {
        this.manager = manager;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(PING_TIME);
            } catch (InterruptedException e) {}
            manager.sendPing();
            try {
                Thread.sleep(RESPOND_TIME);
            } catch (InterruptedException e) {}
            manager.purgeNotResponding();
        }
    }
}
