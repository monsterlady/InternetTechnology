package chat_server;

/**
 * A client has disconnected.
 */
public class NoClientException extends Exception {
}
