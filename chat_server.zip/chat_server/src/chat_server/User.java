package chat_server;

import java.util.HashMap;
import java.util.Map;

/**
 * For every &lt;user&gt;, the database stores an object of this class.
 */
public class User {
    /**
     * &lt;user&gt;
     */
    private final String name;

    /**
     * the groups that &lt;user&gt; is a member of;
     * the map key is the group name
     */
    private final Map<String, Group> groupMap = new HashMap<>();

    public ClientOut getClientOut() {
        return clientOut;
    }

    private ClientOut clientOut;

    public User(String name, ClientOut clientOut) {
        this.name = name;
        this.clientOut = clientOut;
    }

    public String getName() {
        return name;
    }

    public void insertGroup(Group group) {
        groupMap.put(group.getName(), group);
    }

    public boolean isInGroup(String groupName) {
        return groupMap.containsKey(groupName);
    }

    public void deleteGroup(String groupName) { groupMap.remove(groupName);
    }
}
