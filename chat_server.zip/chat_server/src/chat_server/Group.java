package chat_server;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * For every &lt;group&gt;, the database stores an object of this class.
 */
public class Group {
    /**
     * &lt;group&gt;
     */
    private final String name;

    /**
     * the name of the administrator of &lt;group&gt;
     */
    private String adminName;

    /**
     * the names of the members of &lt;group&gt;
     */
    private final Set<String> userSet = new HashSet<>();

    /**
     * the names of the users kicked from &lt;group&gt;
     */
    private final Set<String> bannedUserSet = new HashSet<>();

    public Group(String name, String adminName) {
        this.name = name;
        this.adminName = adminName;
    }

    public String getName() {
        return name;
    }

    public void insertUser(User user) {
        userSet.add(user.getName());
    }

    public String[] selectUserList() {
        return userSet.stream().toArray(String[]::new);
    }

    public boolean isUserIn(String userName) {
        return userSet.contains(userName);
    }

    public void deleteUser(String userName) {
        userSet.remove(userName);
    }

    public void banUser(String userName) {
        bannedUserSet.add(userName);
    }

    public boolean isUserBanned(String userName) {
        return bannedUserSet.contains(userName);
    }

    public String getAdminName() {
        return adminName;
    }
}
