package chat_server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Pattern;

/**
 * For running the server. Also a utility class.
 */
public class Main {
    /**
     * A regular expression of one space character.
     */
    private final static Pattern SPACE = Pattern.compile(" ");

    /**
     * Splits a protocol message into two parts separated by a space character
     * (before that first space character and after).
     * @param msg the protocol message
     * @return the array of parts if the argument contains a space character,
     * {@code null} otherwise. So the array is of length {@code 2}.
     */
    public static String[] splitMsg(String msg) {
        final String[] sa = SPACE.split(msg, 2);
        return sa.length == 2 ? sa : null;
    }

    /**
     * @param name
     * @return if the argument is a valid name of a group or a user
     */
    public static boolean isNameValid(String name) {
        for (int i = 0; i != name.length(); i++) {
            final char c = name.charAt(i);
            if (!(Character.isAlphabetic(c) || Character.isDigit(c) || c == '_')) {
                return false;
            }
        }
        return true;
    }

    private static void printUsage() {
        System.out.println("Usage: java -jar chat_server.jar <chat server port>");
    }

    private static void printError(String message) {
        System.out.println(message);
        printUsage();
    }

    private static void handleClient(Manager manager, Socket clientSocket) throws IOException {
        final ClientOut clientOut = new ClientOut(clientSocket.getOutputStream());
        final BufferedReader clientReader = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
        clientOut.printlnMain("HELO LEVEL 3 Welkom to WhatsUpp!");
        final String line = clientReader.readLine();
        if (line != null) {
            final String[] sa = splitMsg(line);
            if (sa != null && sa[0].equals("HELO")) {
                final String userName = sa[1];
                if (!isNameValid(userName)) {
                    clientOut.printlnMain("-ERR username has an invalid format"
                            +" (only characters, numbers and underscores are allowed)");
                    clientOut.close();
                } else {
                    try {
                        final ClientHandle clientHandle = manager.insertUser(userName, clientOut);
                        if (clientHandle != null) {
                            new Thread(new ClientIn(clientReader, manager, clientHandle)).start();
                        }
                    } catch (NoClientException e) {
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 1) {
            printUsage();
        } else {
            final int serverPort = Integer.parseInt(args[0]);
            if (!(serverPort >= 1 && serverPort < 65536)) {
                printError("The port is out of bounds.");
            } else {
                final Manager manager = new Manager();

                final Thread pingSender = new Thread(new PingSender(manager));
                pingSender.setDaemon(true);
                pingSender.start();

                final ServerSocket serverSocket = new ServerSocket(serverPort);
                while (true) {
                    final Socket clientSocket = serverSocket.accept();
                    handleClient(manager, clientSocket);
                }
            }
        }
    }
}
