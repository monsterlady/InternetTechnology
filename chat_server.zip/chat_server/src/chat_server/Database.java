package chat_server;

import java.util.HashMap;
import java.util.Map;

/**
 * Stores the state of the server: users, groups, and their relationships.
 */
public class Database {
    public enum Result {OK, NO_USER, NO_GROUP,
        USER_IN_GROUP, USER_NOT_IN_GROUP, USER_BANNED, USER_NOT_ADMIN};

    private Map<String, User> userMap = new HashMap<>();
    private Map<String, Group> groupMap = new HashMap<>();

    public void deleteUser(String userName) {
        userMap.remove(userName);
    }

    public User insertUser(String userName, ClientOut clientOut) {
        if (userMap.containsKey(userName)) return null;
        else {
            final User user = new User(userName, clientOut);
            userMap.put(userName, user);
            return user;
        }
    }

    public User selectUser(String userName) {
        return userMap.get(userName);
    }

    public synchronized Group selectGroup(String groupName) {
        return groupMap.get(groupName);
    }

    public User[] selectUserList() {
        return userMap.values().stream().toArray(User[]::new);
    }

    public Group[] selectGroupList() {
        return groupMap.values().stream().toArray(Group[]::new);
    }

    public Group insertGroup(String groupName, User admin) {
        if (groupMap.containsKey(groupName)) return null;
        else {
            final Group group = new Group(groupName, admin.getName());
            groupMap.put(groupName, group);
            return group;
        }
    }

    private void deleteGroup(Group group) {
        for (String userName: group.selectUserList()) {
            final User user = userMap.get(userName);
            if (user != null) {
                user.deleteGroup(group.getName());
            }
        }
        groupMap.remove(group.getName());
    }

    public Result dismissGroup(String groupName, String adminName) {
        final Group group = groupMap.get(groupName);
        if (group == null) return Result.NO_GROUP;
        if (!group.getAdminName().equals(adminName)) return Result.USER_NOT_ADMIN;
        deleteGroup(group);
        return Result.OK;
    }

    public Result userJoinGroup(String groupName, String userName) {
        final User user = userMap.get(userName);
        if (user == null) return Result.NO_USER;
        final Group group = groupMap.get(groupName);
        if (group == null) return Result.NO_GROUP;
        if (user.isInGroup(groupName)) return Result.USER_IN_GROUP;
        if (group.isUserBanned(userName)) return Result.USER_BANNED;
        user.insertGroup(group);
        group.insertUser(user);
        return Result.OK;
    }

    public Result userLeaveGroup(String groupName, String userName) {
        final User user = userMap.get(userName);
        if (user == null) return Result.NO_USER;
        final Group group = groupMap.get(groupName);
        if (group == null) return Result.NO_GROUP;
        if (!user.isInGroup(groupName)) return Result.USER_NOT_IN_GROUP;
        user.deleteGroup(groupName);
        group.deleteUser(userName);
        return Result.OK;
    }

    public Result kickUser(String groupName, String adminName, String userName) {
        final Group group = groupMap.get(groupName);
        if (group == null) return Result.NO_GROUP;
        if (!adminName.equals(group.getAdminName())) return Result.USER_NOT_ADMIN;
        final User user = userMap.get(userName);
        if (user == null) return Result.NO_USER;
        if (!group.isUserIn(userName)) return Result.USER_NOT_IN_GROUP;
        user.deleteGroup(groupName);
        group.deleteUser(userName);
        group.banUser(userName);
        return Result.OK;
    }
}
