package chat_server;

import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Send data to a client.
 */
public class ClientOut implements Closeable {
    private static final NoClientException NO_CLIENT_E = new NoClientException();

    private final BufferedWriter out;
    private boolean connected = true;
    private boolean notResponding = false;

    public ClientOut(OutputStream out) {
        this.out = new BufferedWriter(
                new OutputStreamWriter(out, StandardCharsets.UTF_8));
    }

    public boolean isConnected() {
        return connected;
    }

    public void printlnMain(String s) throws IOException {
        out.write(s);
        out.write('\r');
        out.write('\n');
        out.flush();
    }

    public void println(String s) throws NoClientException {
        if (connected) {
            try {
                printlnMain(s);
            } catch (IOException e) {
                connected = false;
                try {
                    out.close();
                } catch (IOException ex) {
                }
                throw NO_CLIENT_E;
            }
        }
    }

    @Override
    public void close() {
        if (connected) {
            connected = false;
            try {
                out.close();
            } catch (IOException e) {
            }
        }
    }

    public boolean isNotResponding() {
        return notResponding;
    }

    public void setNotResponding(boolean notResponding) {
        this.notResponding = notResponding;
    }
}
