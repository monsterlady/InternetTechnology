package chat_server;

/**
 * For every logged in user, an object of this class is created.
 */
public class ClientHandle {
    private final ClientOut clientOut;
    private final User user;

    public ClientHandle(User user, ClientOut clientOut) {
        this.clientOut = clientOut;
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public String getUserName() {
        return user.getName();
    }

    public boolean isConnected() {
        return clientOut.isConnected();
    }

    public ClientOut getClientOut() {
        return clientOut;
    }
}
