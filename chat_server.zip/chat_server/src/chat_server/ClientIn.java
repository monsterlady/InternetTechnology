package chat_server;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Receive and parse messages from clients.
 */
public class ClientIn implements Runnable {
    private final BufferedReader clientReader;
    private final Manager manager;
    private final ClientHandle clientHandle;

    public ClientIn(BufferedReader clientReader, Manager manager, ClientHandle clientHandle) {
        this.clientReader = clientReader;
        this.manager = manager;
        this.clientHandle = clientHandle;
    }

    @Override
    public void run() {
        try {
            while (true) {
                manager.checkConnected(clientHandle);
                final String line = clientReader.readLine();
                if (line == null) break;
                else {
                    String cmd = line;
                    if (cmd.equals("QUIT")) {
                        manager.quit(clientHandle);
                        break;
                    } else if (cmd.equals("PONG")) manager.pong(clientHandle);
                    else if (cmd.equals("GET_USERS")) manager.sendUserList(clientHandle);
                    else if (cmd.equals("GET_GROUPS")) manager.sendGroupList(clientHandle);
                    else {
                        final String[] sa = Main.splitMsg(line);
                        if (sa == null) manager.unknownCmd(clientHandle);
                        else {
                            cmd = sa[0];
                            if (cmd.equals("BCST")) {
                                manager.sendBroadcast(clientHandle, sa[1]);
                            } else if (cmd.equals("PM")) {
                                final String[] sa1 = Main.splitMsg(sa[1]);
                                if (sa1 == null) manager.unknownCmd(clientHandle);
                                else {
                                    manager.sendPrivate(clientHandle, sa1[0], sa1[1]);
                                }
                            } else if (cmd.equals("FILE_DATA")) {
                                final String[] sa1 = Main.splitMsg(sa[1]);
                                if (sa1 == null) manager.unknownCmd(clientHandle);
                                else {
                                    manager.sendFileData(clientHandle, sa1[0], sa1[1]);
                                }
                            } else if (cmd.equals("FILE_END")) {
                                manager.sendFileEnd(clientHandle, sa[1]);
                            } else if (cmd.equals("FILE_ACCEPT")) {
                                manager.acceptFile(clientHandle, sa[1]);
                            } else if (cmd.equals("GROUP_MESSAGE")) {
                                final String[] sa1 = Main.splitMsg(sa[1]);
                                if (sa1 == null) manager.unknownCmd(clientHandle);
                                else {
                                    final String groupName = sa1[0];
                                    final String doc = sa1[1];
                                    manager.sendToGroup(clientHandle, groupName, doc);
                                }
                            } else if (cmd.equals("CREATE_GROUP")) {
                                final String groupName = sa[1];
                                if (!Main.isNameValid(groupName)) {
                                    manager.println(clientHandle,
                                            "-ERR group name has invalid format");
                                } else manager.createGroup(clientHandle, groupName);
                            } else if (cmd.equals("DISMISS_GROUP")) {
                                final String groupName = sa[1];
                                manager.dismissGroup(clientHandle, groupName);
                            } else if (cmd.equals("JOIN")) {
                                final String groupName = sa[1];
                                manager.userJoinGroup(clientHandle, groupName);
                            } else if (cmd.equals("LEAVE")) {
                                final String groupName = sa[1];
                                manager.userLeaveGroup(clientHandle, groupName);
                            } else if (cmd.equals("KICK")) {
                                final String[] sa1 = Main.splitMsg(sa[1]);
                                if (sa1 == null) manager.unknownCmd(clientHandle);
                                else {
                                    final String groupName = sa1[0];
                                    final String userName = sa1[1];
                                    manager.kick(clientHandle, groupName, userName);
                                }
                            } else if (cmd.equals("FILE_OFFER")) {
                                final String[] sa1 = Main.splitMsg(sa[1]);
                                if (sa1 == null) manager.unknownCmd(clientHandle);
                                else {
                                    manager.offerFile(clientHandle, sa1[0], sa1[1]);
                                }
                            } else manager.unknownCmd(clientHandle);
                        }
                    }
                }
            }
        } catch (IOException e) {
        } catch (NoClientException e) {
        } finally {
            manager.close(clientHandle);
        }
    }
}
