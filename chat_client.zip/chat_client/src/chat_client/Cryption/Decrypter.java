/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

/**
 * Decrypt binary data (a file) by parts according to the protocol.
 * It can be used in two ways:
 * <ul>
 *     <li>send all parts to {@link #update(String)},
 *     send the empty array to {@link #doFinal(String)};</li>
 *     <li>send all parts except the last to {@link #update(String)},
 *     send the last part to {@link #doFinal(String)}.</li>
 * </ul>
 * In any case, {@link #doFinal(String)} must be called
 * to get the data buffered in the cipher implementation.
 */
public class Decrypter {
    private final Cipher cipher;
    private boolean ivReceived = false;
    private Key key;

    public Decrypter(Key key) throws CryptoException {
        this.key = key;
        try {
            cipher = Cipher.getInstance("AES/GCM/NoPadding");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new CryptoException(e);
        }
    }

    private ByteBuffer prepareBuffer(String cipherText)
            throws CryptoException, CryptoDataException {
        final byte[] data;
        try {
            data = Base64.getDecoder().decode(cipherText);
        } catch (IllegalArgumentException e) {
            throw new CryptoDataException(e);
        }
        final int fromIndex;
        if (!ivReceived) {
            byte[] iv = Arrays.copyOfRange(data, 0, 12);
            try {
                cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
            } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
                throw new CryptoException(e);
            }
            fromIndex = iv.length;
            key = null;
            ivReceived = true;
        } else fromIndex = 0;
        return ByteBuffer.wrap(data, fromIndex, data.length - fromIndex);
    }

    public byte[] update(String cipherText) throws CryptoException, CryptoDataException {
        final ByteBuffer buffer = prepareBuffer(cipherText);
        return cipher.update(buffer.array(), buffer.position(), buffer.remaining());
    }

    public byte[] doFinal(String cipherText) throws CryptoException, CryptoDataException {
        final ByteBuffer buffer = prepareBuffer(cipherText);
        try {
            return cipher.doFinal(buffer.array(), buffer.position(), buffer.remaining());
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            throw new CryptoDataException(e);
        }
    }

    public boolean hasKey() {
        return key != null;
    }
}
