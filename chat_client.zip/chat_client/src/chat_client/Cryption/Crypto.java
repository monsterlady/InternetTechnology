/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;
import java.util.Random;

/**
 * Contains the state of the cryptographic system,
 * for example, a secure random number generator.
 * IV means “initial vector for Galois/Counter Mode (GCM) of operation”
 */
public class Crypto {
    public static String byteBufferToBase64(ByteBuffer buffer) {
        return StandardCharsets.US_ASCII.decode(
                Base64.getEncoder().withoutPadding().encode(buffer)).toString();
    }

    /**
     * @param keyString a 128-bit key encoded as a text
     *                  using the basic variant of the Base64 encoding
     *                  without padding according to RFC 4648 and RFC 2045
     * @return the cryptographic key
     * @throws IllegalArgumentException if the argument has invalid format
     */
    public static SecretKey stringToKey(String keyString) {
        byte[] keyBytes = Base64.getDecoder().decode(keyString);
        if (keyBytes.length != 16) throw new IllegalArgumentException();
        return new SecretKeySpec(keyBytes, "AES");
    }

    /**
     * @param key a cryptographic key
     * @return the key encoded as the argument of {@link #stringToKey(String)}
     */
    public static String keyToString(SecretKey key) {
        return Base64.getEncoder().withoutPadding().encodeToString(key.getEncoded());
    }

    public static int getIvLength() {
        return 12;
    }

    /**
     * Decrypt a private message according to the protocol.
     * @param key the cryptographic key
     * @param cipherText the user message &lt;data&gt; in the protocol message
     * @return the user message
     * @throws CryptoException
     * @throws CryptoDataException
     */
    public static String decrypt(SecretKey key, String cipherText)
            throws CryptoException, CryptoDataException {
        try {
            final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            final byte[] buffer;
            try {
                buffer = Base64.getDecoder().decode(cipherText);
            } catch (IllegalArgumentException e) {
                throw new CryptoDataException(e);
            }
            cipher.init(Cipher.DECRYPT_MODE, key,
                    new GCMParameterSpec(128, Arrays.copyOfRange(buffer, 0, getIvLength())));
            if (buffer.length < getIvLength()) throw new CryptoDataException();
            return new String(cipher.doFinal(buffer, getIvLength(), buffer.length - getIvLength()),
                    StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException
                | InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new CryptoException(e);
        } catch (BadPaddingException | IllegalBlockSizeException e) {
            throw new CryptoDataException(e);
        }
    }

    private final Random secureRandom = new SecureRandom();

    /**
     * Generate a new IV.
     * @return the IV
     */
    public byte[] genIv() {
        byte[] iv = new byte[getIvLength()]; /* never reuse this IV with the same key */
        secureRandom.nextBytes(iv);
        return iv;
    }

    /**
     * Generate a new cryptographic key.
     * @return the key
     */
    public SecretKey genKey() {
        byte[] keyBytes = new byte[16];
        secureRandom.nextBytes(keyBytes);
        return new SecretKeySpec(keyBytes, "AES");
    }

    /**
     * Encrypt a private message according to the protocol.
     * @param key the cryptographic key
     * @param doc the user message
     * @return the user message &lt;data&gt; in the protocol message
     * @throws CryptoException
     */
    public String encrypt(SecretKey key, String doc) throws CryptoException {
        try {
            final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            final byte[] iv = genIv();
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
            final byte[] docBytes = cipher.doFinal(doc.getBytes(StandardCharsets.UTF_8));
            final byte[] buffer = new byte[iv.length + docBytes.length];
            {
                ByteBuffer buffer1 = ByteBuffer.wrap(buffer);
                buffer1.put(iv);
                buffer1.put(docBytes);
            }
            return byteBufferToBase64(ByteBuffer.wrap(buffer));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException
                | InvalidKeyException | InvalidAlgorithmParameterException
                | IllegalBlockSizeException | BadPaddingException e) {
            throw new CryptoException(e);
        }
    }
}
