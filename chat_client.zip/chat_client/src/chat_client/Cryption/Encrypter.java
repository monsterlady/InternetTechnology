/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

/**
 * Encrypt binary data (a file) by parts according to the protocol.
 * It can be used in two ways:
 * <ul>
 *     <li>send all parts to {@link #update(ByteBuffer)},
 *     send the empty array to {@link #doFinal(ByteBuffer)};</li>
 *     <li>send all parts except the last to {@link #update(ByteBuffer)},
 *     send the last part to {@link #doFinal(ByteBuffer)}.</li>
 * </ul>
 * In any case, {@link #doFinal(ByteBuffer)} must be called
 * to get the data buffered in the cipher implementation.
 */
public class Encrypter {
    private final byte[] iv;
    private final Cipher cipher;
    private byte[] buffer = new byte[1 << 5];
    private boolean ivSent = false;

    public Encrypter(Crypto crypto, Key key) throws CryptoException {
        iv = crypto.genIv();
        try {
            cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException
                | InvalidKeyException | InvalidAlgorithmParameterException e) {
            throw new CryptoException(e);
        }
    }

    private void extendBuffer(int newLength) {
        if (buffer.length < newLength) buffer = new byte[
                Math.max(newLength, 2 * buffer.length)];
    }

    private ByteBuffer prepareBuffer(ByteBuffer plainText) {
        final int outputSize = cipher.getOutputSize(plainText.remaining());
        final ByteBuffer cipherText;
        if (!ivSent) {
            extendBuffer(iv.length + outputSize);
            cipherText = ByteBuffer.wrap(buffer);
            cipherText.put(iv);
            ivSent = true;
        } else {
            extendBuffer(outputSize);
            cipherText = ByteBuffer.wrap(buffer);
        }
        return cipherText;
    }

    public String update(ByteBuffer plainText) throws CryptoException {
        final ByteBuffer cipherText = prepareBuffer(plainText);
        try {
            cipher.update(plainText, cipherText);
        } catch (ShortBufferException e) {
            throw new CryptoException(e);
        }
        return Crypto.byteBufferToBase64(ByteBuffer.wrap(buffer, 0, cipherText.position()));
    }

    public String doFinal(ByteBuffer plainText) throws CryptoException {
        final ByteBuffer cipherText = prepareBuffer(plainText);
        try {
            cipher.doFinal(plainText, cipherText);
        } catch (ShortBufferException | IllegalBlockSizeException | BadPaddingException e) {
            throw new CryptoException(e);
        }
        return Crypto.byteBufferToBase64(ByteBuffer.wrap(buffer, 0, cipherText.position()));
    }
}
