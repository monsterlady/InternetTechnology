/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

/**
 * The parameters of the file offered to the user controlling the client.
 */
public class FileDescrIn {
    private final long length;
    private final boolean isEncrypted;

    public FileDescrIn(long length, boolean isEncrypted) {
        this.length = length;
        this.isEncrypted = isEncrypted;
    }

    public long getLength() {
        return length;
    }

    public boolean isEncrypted() {
        return isEncrypted;
    }
}
