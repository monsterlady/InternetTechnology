/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

/**
 * Cryptographic data received from the server are invalid.
 */
public class CryptoDataException extends Exception {
    public CryptoDataException() {
    }

    public CryptoDataException(Throwable throwable) {
        super(throwable);
    }
}
