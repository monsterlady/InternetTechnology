/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import java.io.IOException;
import java.io.OutputStream;
import java.security.Key;
import java.util.Base64;

/**
 * Decode file data from the server and write them to a file.
 */
public class TransmissionIn {
    private final OutputStream out;
    private Decrypter decrypter;
    private long remaining;
    private final boolean encrypted;

    public TransmissionIn(boolean encrypted, Key key, OutputStream out, long fileLength)
            throws CryptoException {
        this.encrypted = encrypted;
        this.decrypter = encrypted ? new Decrypter(key) : null;
        this.out = out;
        this.remaining = fileLength;
    }

    private boolean writeLimited(byte[] data) throws IOException {
        int dataLength = (int) Math.min(data.length, remaining);
        out.write(data, 0, dataLength);
        remaining -= dataLength;
        return remaining != 0;
    }

    /**
     * @param dataString
     * @return
     * @throws IOException
     * @throws CryptoException
     * @throws CryptoDataException
     * @throws IllegalArgumentException if the argument has invalid format
     */
    public boolean update(String dataString)
            throws IOException, CryptoException, CryptoDataException {
        return writeLimited(encrypted ? decrypter.update(dataString)
                : Base64.getDecoder().decode(dataString));
    }

    /**
     * @param dataString
     * @return
     * @throws IOException
     * @throws CryptoException
     * @throws CryptoDataException
     * @throws IllegalArgumentException if the argument has invalid format
     */
    public boolean doFinal(String dataString)
            throws IOException, CryptoException, CryptoDataException {
        return writeLimited(encrypted ? decrypter.doFinal(dataString)
                : Base64.getDecoder().decode(dataString));
    }

    public void close() throws IOException {
        decrypter = null;
        out.close();
    }

    public boolean hasKey() {
        return decrypter != null && decrypter.hasKey();
    }
}
