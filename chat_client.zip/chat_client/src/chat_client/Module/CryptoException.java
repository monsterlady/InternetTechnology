/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

/**
 * Error in the program code performing a cryptographic operation.
 */
public class CryptoException extends Exception {
    public CryptoException(Throwable throwable) {
        super(throwable);
    }
}
