/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.SecretKey;
import java.nio.file.Path;

/**
 * For every &lt;user b&gt;, the database stores an object of this class.
 * In field descriptions, &lt;user&gt; is the user controlling the client.
 */
public class User {
    /**
     * the name of &lt;user b&gt;
     */
    private final String name;

    /**
     * the key assigned to &lt;user b&gt; by &lt;user&gt;
     */
    private SecretKey key;

    /**
     * the parameters of a file currently offered to &lt;user&gt; by &lt;user b&gt;
     */
    private FileDescrIn fileDescrIn;

    /**
     * the state of the transmission of the file from &lt;user b&gt; to &lt;user&gt;
     */
    private TransmissionIn transmissionIn;

    /**
     * the path of the file offered to &lt;user b&gt; by &lt;user&gt;
     */
    private Path pathOut;

    public User(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public SecretKey getKey() {
        return key;
    }

    public void setKey(SecretKey key) {
        this.key = key;
    }

    public FileDescrIn getFileDescrIn() {
        return fileDescrIn;
    }

    public void setFileDescrIn(FileDescrIn fileDescrIn) {
        this.fileDescrIn = fileDescrIn;
    }

    public TransmissionIn getTransmissionIn() {
        return transmissionIn;
    }

    public void setTransmissionIn(TransmissionIn transmissionIn) {
        this.transmissionIn = transmissionIn;
    }

    public boolean hasKey() {
        return key != null;
    }

    public Path getPathOut() {
        return pathOut;
    }

    public void setPathOut(Path pathOut) {
        this.pathOut = pathOut;
    }

    public boolean isTransmissionGoing() {
        return transmissionIn != null && transmissionIn.hasKey();
    }
}
