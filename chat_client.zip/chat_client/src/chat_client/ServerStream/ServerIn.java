/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import java.io.BufferedReader;
import java.io.IOException;

/**
 * Receive and parse server messages.
 */
public class ServerIn implements Runnable {
    private final BufferedReader in;
    private Manager manager;

    public ServerIn(BufferedReader in, Manager manager) {
        this.manager = manager;
        this.in = in;
    }

    @Override
    public void run() {
        try {
            while (true) {
                manager.checkConnected();
                String line = in.readLine();
                if (line == null) break;
                if (line.equals("PING")) manager.ping();
                else {
                    final String[] sa = Main.splitMsg(line);
                    if (sa == null) manager.invalidServerMsg(line);
                    final String cmd = sa[0];
                    if (cmd.equals("-ERR")) manager.error(sa[1]);
                    else if (cmd.equals("+OK")) {
                        final String[] sa1 = Main.splitMsg(sa[1]);
                        {
                            final String cmd1;
                            final String list;
                            if (sa1 == null) {
                                cmd1 = sa[1];
                                list = "";
                            } else {
                                cmd1 = sa1[0];
                                list = sa1[1];
                            }
                            if (cmd1.equals("GET_USERS")) {
                                manager.printlnUser("!users: " + list);
                            } else if (cmd1.equals("GET_GROUPS")) {
                                manager.printlnUser("!groups: " + list);
                            }
                        }
                        if (sa1 != null) {
                            final String cmd1 = sa1[0];
                            if (cmd1.equals("CREATE_GROUP")) {
                                final String groupName = sa1[1];
                                manager.printlnUser("!group \"" + groupName + "\" created");
                            } else if (cmd1.equals("DISMISS_GROUP")) {
                                final String groupName = sa1[1];
                                manager.printlnUser("!group \"" + groupName + "\" dismissed");
                            } else if (cmd1.equals("JOIN")) {
                                final String groupName = sa1[1];
                                manager.printlnUser("!you have joined group \"" + groupName + "\"");
                            } else if (cmd1.equals("LEAVE")) {
                                final String groupName = sa1[1];
                                manager.printlnUser("!you have left group \"" + groupName + "\"");
                            } else if (cmd1.equals("KICK")) {
                                final String[] sa2 = Main.splitMsg(sa1[1]);
                                final String groupName = sa2[0];
                                final String userName = sa2[1];
                                manager.printlnUser("!you kicked user \"" + userName
                                        + "\" from group \"" + groupName + "\"");
                            }
                        }
                    } else if (cmd.equals("PM")) {
                        final String[] sa1 = Main.SPACE.split(sa[1], 3);
                        if (sa1.length != 3) manager.invalidServerMsg(line);
                        else {
                            final String senderUserName = Main.unpackUserName(sa1[0]);
                            final String isEncryptedString = sa1[1];
                            final String doc = sa1[2];
                            Boolean isEncrypted = Manager.parseIsEncrypted(isEncryptedString);
                            if (isEncrypted == null) manager.invalidServerMsg(line);
                            else {
                                manager.receivePrivate(senderUserName, isEncrypted, doc);
                            }
                        }
                    } else if (cmd.equals("BCST")) {
                        final String[] sa1 = Main.splitMsg(sa[1]);
                        if (sa1 == null) manager.invalidServerMsg(line);
                        else {
                            final String fromUser = Main.unpackUserName(sa1[0]);
                            final String doc = sa1[1];
                            manager.printlnUser(fromUser + ": " + doc);
                        }
                    } else if (cmd.equals("GROUP_MESSAGE")) {
                        final String[] sa1 = Main.SPACE.split(sa[1], 3);
                        if (sa1.length != 3) manager.invalidServerMsg(line);
                        else {
                            final String groupName = sa1[0];
                            final String fromUser = Main.unpackUserName(sa1[1]);
                            final String doc = sa1[2];
                            manager.printlnUser(groupName + "/" + fromUser + ": " + doc);
                        }
                    } else if (cmd.equals("KICKED")) {
                        final String groupName = sa[1];
                        manager.printlnUser("!you were kicked from group \"" + groupName + "\"");
                    } else if (cmd.equals("FILE_OFFER")) {
                        final String[] sa1 = Main.SPACE.split(sa[1], 4);
                        if (sa1.length != 4) manager.invalidServerMsg(line);
                        else {
                            final String isEncryptedString = sa1[2];
                            final Boolean isEncrypted = Manager.parseIsEncrypted(isEncryptedString);
                            if (isEncrypted == null) manager.invalidServerMsg(line);
                            else {
                                final String senderUserName = sa1[0];
                                try {
                                    final String filename = sa1[3];
                                    final long fileLength = Long.parseLong(sa1[1]);
                                    manager.fileOffered(senderUserName, fileLength, isEncrypted,filename);
                                } catch (NumberFormatException e) {
                                    manager.invalidServerMsg(line);
                                }
                            }
                        }
                    } else if (cmd.equals("FILE_ACCEPT")) manager.fileAccepted(sa[1]);
                    else if (cmd.equals("FILE_DATA")) {
                        final String[] sa1 = Main.splitMsg(sa[1]);
                        if (sa1 == null) manager.invalidServerMsg(line);
                        else {
                            final String senderUserName = sa1[0];
                            final String data = sa1[1];
                            manager.receiveFileData(senderUserName, data);
                        }
                    } else if (cmd.equals("FILE_END")) manager.receiveFileEnd(sa[1]);
                    else manager.invalidServerMsg(line);
                }
            }
        } catch (IOException e) {
        } catch (CryptoException e) {
            manager.printStackTrace(e);
        } catch (NoServerException e) {
        } finally {
            manager.close();
        }
    }

}
