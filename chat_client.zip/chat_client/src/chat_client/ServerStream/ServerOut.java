/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Send messages to the server.
 */
public class ServerOut {
    private final BufferedWriter out;
    private boolean connected = true;

    public ServerOut(OutputStream out) {
        this.out = new BufferedWriter(
                new OutputStreamWriter(out, StandardCharsets.UTF_8));
    }

    public boolean isConnected() {
        return connected;
    }

    public void close() {
        if (connected) {
            connected = false;
            try {
                out.close();
            } catch (IOException ex) {
            }
        }
    }

    public void printlnMain(String s) throws IOException {
        out.write(s);
        out.write('\r');
        out.write('\n');
        out.flush();
    }

    public void println(String s) throws NoServerException {
        if (connected) {
            try {
                printlnMain(s);
            } catch (IOException e) {
                connected = false;
                try {
                    out.close();
                } catch (IOException ex) {
                }
            }
        }
    }
}
