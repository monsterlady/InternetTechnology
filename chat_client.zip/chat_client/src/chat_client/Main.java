/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.util.regex.Pattern;

/**
 * For running the client. Also a utility class.
 */
public class Main {
    /**
     * A regular expression of one space character.
     */
    public final static Pattern SPACE = Pattern.compile(" ");

    /**
     * A regular expression of a non-empty sequence of space characters.
     */
    private final static Pattern SPACE_USER = Pattern.compile("\\s+");

    /**
     * Splits a protocol message into two parts separated by a space character
     * (before that first space character and after).
     * @param msg the protocol message
     * @return the array of parts if the argument contains a space character,
     * {@code null} otherwise. So the array is of length {@code 2}.
     */
    public static String[] splitMsg(String msg) {
        final String[] sa = SPACE.split(msg, 2);
        return sa.length == 2 ? sa : null;
    }

    /**
     * Splits a user command into two parts separated
     * by a non-empty sequence of space characters.
     * @param line the user command
     * @return the array of parts if the argument contains a space character,
     * {@code null} otherwise. So the array is of length {@code 2}.
     */
    public static String[] splitUserCmd(String line) {
        final String[] sa = SPACE_USER.split(line, 2);
        return sa.length == 2 ? sa : null;
    }

    /**
     * Strips square brackets from a user name.
     * This is how the provided server sends user names.
     * @param s the user name as given by the server
     * @return the real user name
     */
    public static String unpackUserName(String s) {
        if (s.charAt(0) == '[') return s.substring(1, s.length() - 1);
        else return s;
    }

    private static void printUsage() {
        System.out.println("Usage: java -jar chat_client.jar"
                + " <chat server host> <chat server port> <user name>");
    }

    private static void printError(String msg) {
        System.out.println(msg);
        printUsage();
    }

    private static Integer parseProtocolLevel(String msg) {
        String[] sa1 = Main.splitMsg(msg);
        Integer protocolLevel = null;
        if (sa1 == null || !sa1[0].equals("LEVEL")) protocolLevel = 1;
        else {
            final String levelString = sa1[1];
            String[] sa2 = Main.splitMsg(levelString);
            if (sa2 == null) {
            } else {
                try {
                    protocolLevel = Integer.parseInt(sa2[0]);
                } catch (NumberFormatException e) {}
            }
        }
        return protocolLevel;
    }

    private static void connect(String serverHostName, int serverPort, String userName)
            throws IOException {
        final UserOut userOut = new UserOut();
        try (final Socket socket = new Socket(InetAddress.getByName(serverHostName),
                serverPort)) {
            final ServerOut serverOut = new ServerOut(socket.getOutputStream());
            final BufferedReader serverReader = new BufferedReader(new InputStreamReader(
                    socket.getInputStream()));
            String line = serverReader.readLine();
            if (line == null) userOut.serverDisconnected();
            else {
                String[] sa = splitMsg(line);
                if (!(sa != null && sa[0].equals("HELO"))) {
                    userOut.invalidServerMsg(line);
                } else {
                    String msg = sa[1];
                    final Integer protocolLevel = parseProtocolLevel(msg);
                    if (protocolLevel == null) {
                        userOut.println("!invalid server protocol level: " + msg);
                    } else if (!(1 <= protocolLevel && protocolLevel <= 3)) {
                        userOut.println("!unsupported server protocol level: " + protocolLevel);
                    } else {
                        userOut.println("!server protocol level: " + protocolLevel);
                        serverOut.printlnMain("HELO " + userName);
                        String line1 = serverReader.readLine();
                        if (line1 == null) userOut.serverDisconnected();
                        else {
                            String[] sa2 = splitMsg(line1);
                            if (sa2 == null) userOut.invalidServerMsg(line1);
                            else if (sa2[0].equals("-ERR")) userOut.serverError(sa2[1]);
                            else if (sa2[0].equals("+OK")) {
                                final Crypto crypto = new Crypto();
                                final Manager manager = new Manager(serverOut, userOut, crypto);
                                final Thread serverInThread = new Thread(
                                        new ServerIn(serverReader, manager));
                                serverInThread.setDaemon(true);
                                serverInThread.start();
                                final BufferedReader in = new BufferedReader(
                                        new InputStreamReader(System.in));
                                new UserIn(in, manager, protocolLevel).run();
                            } else userOut.invalidServerMsg(line1);
                        }
                    }
                }
            }
        }
    }

    public static void main(String[] args) throws IOException {
	    if (args.length != 3) printUsage();
        else {
            final int serverPort = Integer.parseInt(args[1]);
            if (!(serverPort >= 1 && serverPort < 65536)) {
                printError("The port is out of bounds.");
            } else {
                final String serverHostName = args[0];
                final String userName = args[2];
                connect(serverHostName, serverPort, userName);
            }
        }
    }
}
