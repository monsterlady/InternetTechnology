/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.SecretKey;
import javax.security.auth.DestroyFailedException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Handle user commands and server messages.
 */
public class Manager {
    private static final NoServerException NO_SERVER_E = new NoServerException();

    public static Boolean parseIsEncrypted(String s) {
        return s.equals("CRYPTO") ? true : (s.equals("PLAIN") ? false : null);
    }

    private final Crypto crypto;
    private final Database db = new Database();
    private final ServerOut serverOut;
    private final UserOut userOut;

    public Manager(ServerOut serverOut, UserOut userOut, Crypto crypto) {
        this.serverOut = serverOut;
        this.userOut = userOut;
        this.crypto = crypto;
    }

    public synchronized void close() {
        serverOut.close();
    }

    public synchronized void checkConnected() throws NoServerException {
        if (!serverOut.isConnected()) {
            userOut.serverDisconnected();
            throw NO_SERVER_E;
        }
    }

    /**
     * Handle "PING" from the server.
     * @throws NoServerException
     */
    public synchronized void ping() throws NoServerException {
        checkConnected();
        serverOut.println("PONG");
    }

    /**
     * Handle the user command to terminate the client.
     * @throws NoServerException
     */
    public synchronized void quit() throws NoServerException {
        checkConnected();
        serverOut.println("QUIT");
    }

    public synchronized void printlnUser(String msg) {
        userOut.println(msg);
    }

    public void protocolLevelLow() {
        printlnUser("!the server protocol level is too low for this command");
    }

    public void invalidUserPath() {
        printlnUser("!invalid path");
    }

    public void invalidUserCmd() {
        printlnUser("!invalid user action");
    }

    public synchronized void error(String msg) {
        userOut.serverError(msg);
    }

    public synchronized void invalidServerMsg(String msg) {
        userOut.invalidServerMsg(msg);
    }

    public synchronized void printStackTrace(Throwable e) {
        userOut.printStackTrace(e);
    }

    /**
     * Handle the user command to get the list of users logged into the server.
     * @throws NoServerException
     */
    public synchronized void queryUserList() throws NoServerException {
        checkConnected();
        serverOut.println("GET_USERS");
    }

    /**
     * Handle the user command to make the argument the current group.
     * @param groupName
     */
    public synchronized void setCurrentGroup(String groupName) {
        if (groupName != null && groupName.contains(" ")) {
            userOut.println("!group name contains space");
        } else db.setCurrentGroup(groupName);
    }

    /**
     * Handle the user command to send a message (the argument) to the current group.
     * @param doc
     * @throws NoServerException
     */
    public synchronized void sendUserMsg(String doc) throws NoServerException {
        checkConnected();
        if (db.getCurrentGroup() == null) {
            serverOut.println("BCST " + doc);
        } else {
            serverOut.println("GROUP_MESSAGE " + db.getCurrentGroup() + " " + doc);
        }
    }

    /**
     * Handle the user command to send the private message {@code doc}
     * to the user {@code recipientUserName}.
     * @param recipientUserName
     * @param doc
     * @throws CryptoException
     * @throws NoServerException
     */
    public synchronized void sendPrivate(String recipientUserName, String doc)
            throws CryptoException, NoServerException {
        checkConnected();
        final User user = db.getUser(recipientUserName);
        serverOut.println("PM " + recipientUserName
                + " " + (user.hasKey()
                ? "CRYPTO " + crypto.encrypt(user.getKey(), doc)
                : "PLAIN " + doc));
    }

    /**
     * Handle "PM" from the server.
     * @param senderUserName
     * @param isEncrypted
     * @param doc
     * @throws CryptoException
     */
    public synchronized void receivePrivate(String senderUserName, boolean isEncrypted, String doc)
            throws CryptoException {
        final User user = db.getUser(senderUserName);
        if (isEncrypted && !user.hasKey()) {
            userOut.println("!user \"" + senderUserName
                    + "\" sent you an encrypted message,"
                    + " but you did not assign them a key");
        } else {
            try {
                userOut.println("%" + (isEncrypted ? "#" : "") + senderUserName
                        + ": " + (isEncrypted ? Crypto.decrypt(user.getKey(), doc) : doc));
            } catch (CryptoDataException e) {
                userOut.println("!error decrypting a private message");
            }
        }
    }

    /**
     * Handle the user command to get the list of groups registered on the server.
     * @throws NoServerException
     */
    public synchronized void queryGroupList() throws NoServerException {
        checkConnected();
        serverOut.println("GET_GROUPS");
    }

    /**
     * Handle the user command to create the group {@code groupName} on the server.
     * @param groupName
     * @throws NoServerException
     */
    public synchronized void createGroup(String groupName) throws NoServerException {
        checkConnected();
        serverOut.println("CREATE_GROUP " + groupName);
        serverOut.println("JOIN " + groupName);
    }

    /**
     * Handle the user command to dismiss (delete) a group on the server.
     * @param groupName
     * @throws NoServerException
     */
    public synchronized void dismissGroup(String groupName) throws NoServerException {
        checkConnected();
        serverOut.println("DISMISS_GROUP " + groupName);
    }

    /**
     * Handle the user command to join a group.
     * @param groupName
     * @throws NoServerException
     */
    public synchronized void userJoinGroup(String groupName) throws NoServerException {
        checkConnected();
        serverOut.println("JOIN " + groupName);
    }

    /**
     * Handle the user command to leave the group {@code groupName}.
     * @param groupName
     * @throws NoServerException
     */
    public synchronized void userLeaveGroup(String groupName) throws NoServerException {
        checkConnected();
        serverOut.println("LEAVE " + groupName);
    }

    /**
     * Handle the user command to kick the user {@code userName}
     * from the group {@code groupName}.
     * @param groupName
     * @param userName
     * @throws NoServerException
     */
    public synchronized void kick(String groupName, String userName)
            throws NoServerException {
        checkConnected();
        serverOut.println("KICK " + groupName + " " + userName);
    }

    private Object clearKeyInternal(User user) {
        DestroyFailedException r = null;
        try {
            SecretKey key = user.getKey();
            if (key != null) key.destroy();
        } catch (DestroyFailedException e) {
            r = e;
        }
        user.setKey(null);
        return r;
    }

    /**
     * Handle the user command to clear the cryptographic key for the user {@code userName}.
     * @param userName
     */
    public synchronized void clearKey(String userName) {
        final User user = db.getUser(userName);
        if (user.isTransmissionGoing()) userOut.transmissionIsGoing();
        else {
            final Object r = clearKeyInternal(user);
            userOut.println("!encryption key cleared for user " + userName);
            if (r instanceof DestroyFailedException) userOut.failDestroyKey();
        }
    }

    /**
     * Handle the user command to generate a new cryptographic key
     * for the user {@code userName}.
     * @param userName
     */
    public synchronized void genKey(String userName) {
        final User user = db.getUser(userName);
        if (user.isTransmissionGoing()) userOut.transmissionIsGoing();
        else {
            final Object r = clearKeyInternal(user);
            SecretKey key = crypto.genKey();
            user.setKey(key);
            userOut.println("!encryption key " + Crypto.keyToString(key)
                    + " set for user " + userName);
            if (r instanceof DestroyFailedException) userOut.failDestroyKey();
        }
    }

    /**
     * Handle the user command to assign the cryptographic key {@code key}
     * to the user {@code userName}.
     * @param userName
     * @param key
     */
    public synchronized void setKey(String userName, SecretKey key) {
        final User user = db.getUser(userName);
        if (user.isTransmissionGoing()) userOut.transmissionIsGoing();
        else {
            final Object r = clearKeyInternal(user);
            user.setKey(key);
            userOut.println("!encryption key set for user " + userName);
            if (r instanceof DestroyFailedException) userOut.failDestroyKey();
        }
    }

    /**
     * Handle the user command to offer the file {@code path} of length {@code length}
     * to the user {@code recipientUserName}.
     * @param recipientUserName
     * @param path
     * @param length
     * @throws NoServerException
     */
    public synchronized void offerFile(String recipientUserName, Path path, long length)
            throws NoServerException {
        checkConnected();
        final User user = db.getUser(recipientUserName);
        user.setPathOut(path);
        serverOut.println("FILE_OFFER " + recipientUserName
                + " " + length + " " + (user.hasKey() ? "CRYPTO" : "PLAIN") + " " + path.getFileName());
    }

    /**
     * Handle "FILE_OFFER" from the server.
     * @param senderUserName
     * @param length
     * @param isEncrypted
     */
    public synchronized void fileOffered(String senderUserName, long length, boolean isEncrypted,String filename) {
        db.getUser(senderUserName).setFileDescrIn(new FileDescrIn(length, isEncrypted));
        userOut.println("!user " + senderUserName + " offers you "
                + (isEncrypted ? "an encrypted" : "a")
                + " file of size " + length + " bytes; " + "File Name : " + filename + "\n || You may accept by :faccept " + senderUserName + " PathToSave");
    }

    /**
     * Handle the user command to accept the file offered by {@code senderUserName}.
     * Write that file to {@code out}.
     * @param senderUserName
     * @param out
     * @throws CryptoException
     * @throws NoServerException
     */
    public synchronized void acceptFile(String senderUserName, OutputStream out)
            throws CryptoException, NoServerException {
        checkConnected();
        final User senderUser = db.getUser(senderUserName);
        final FileDescrIn fileDescrIn = senderUser.getFileDescrIn();
        if (fileDescrIn == null) {
            userOut.println("!user did not offer you any file");
        } else {
            if (fileDescrIn.isEncrypted() && !senderUser.hasKey()) {
                userOut.println("!cannot receive an encrypted file because no key is set for user");
            } else {
                senderUser.setFileDescrIn(null);
                senderUser.setTransmissionIn(new TransmissionIn(fileDescrIn.isEncrypted(), senderUser.getKey(),
                        out, fileDescrIn.getLength()));
                serverOut.println("FILE_ACCEPT " + senderUserName);
            }
        }
    }

    /**
     * Handle "FILE_DATA" from the server.
     * @param senderUserName
     * @param data
     * @throws CryptoException
     */
    public synchronized void receiveFileData(String senderUserName, String data) throws CryptoException {
        final User user = db.getUser(senderUserName);
        final TransmissionIn transmissionIn = user.getTransmissionIn();
        if (transmissionIn != null) {
            boolean cont = false;
            try {
                cont = transmissionIn.update(data);
                if (!cont) {
                    userOut.fileReceived(senderUserName);
                }
            } catch (IOException e) {
                userOut.errorWritingFile();
            } catch (CryptoDataException | IllegalArgumentException e) {
                userOut.errorTransmission();
            }
            if (!cont) {
                user.setTransmissionIn(null);
                try {
                    transmissionIn.close();
                } catch (IOException ex) {
                    userOut.printStackTrace(ex);
                }
            }
        }
    }

    /**
     * Handle "FILE_END" from the server.
     * @param senderUserName
     * @throws CryptoException
     */
    public synchronized void receiveFileEnd(String senderUserName) throws CryptoException {
        final User user = db.getUser(senderUserName);
        final TransmissionIn transmissionIn = user.getTransmissionIn();
        if (transmissionIn != null) {
            try {
                transmissionIn.doFinal("");
                userOut.fileReceived(senderUserName);
            } catch (IOException e) {
                userOut.errorWritingFile();
            } catch (CryptoDataException | IllegalArgumentException e) {
                userOut.errorTransmission();
            }
            user.setTransmissionIn(null);
            try {
                transmissionIn.close();
            } catch (IOException ex) {
                userOut.printStackTrace(ex);
            }
        }
    }

    /**
     * Handle "FILE_ACCEPT" from the server.
     * @param recipientUserName
     * @throws CryptoException
     * @throws NoServerException
     */
    public synchronized void fileAccepted(String recipientUserName)
            throws CryptoException, NoServerException {
        checkConnected();
        final User user = db.getUser(recipientUserName);
        final Path path = user.getPathOut();
        if (path != null) {
            final boolean encrypted = user.hasKey();
            final Encrypter encrypter = encrypted ? new Encrypter(crypto, user.getKey()) : null;
            final String msgPrefix = "FILE_DATA " + recipientUserName + " ";
            final byte[] buffer = new byte[1 << 14];
            try (final InputStream in = Files.newInputStream(path)){
                while (true) {
                    final int length = in.read(buffer);
                    if (length == -1) break;
                    final ByteBuffer data1 = ByteBuffer.wrap(buffer, 0, length);
                    serverOut.println(msgPrefix
                            + (encrypted ? encrypter.update(data1) : Crypto.byteBufferToBase64(data1)));
                }
                if (encrypted) {
                    serverOut.println(msgPrefix
                            + encrypter.doFinal(ByteBuffer.wrap(buffer, 0, 0)));
                }
                serverOut.println("FILE_END " + recipientUserName);
                userOut.println("!file sent to user \"" + recipientUserName + "\"");
            } catch (IOException e) {
                userOut.println("!error reading file");
            }
        }
    }
}
