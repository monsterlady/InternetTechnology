/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import java.util.HashMap;
import java.util.Map;

/**
 * Stores the state of the client:
 * users and their attributes and the current group.
 */
public class Database {
    private final Map<String, User> userMap = new HashMap<>();

    public String getCurrentGroup() {
        return currentGroup;
    }

    public void setCurrentGroup(String currentGroup) {
        this.currentGroup = currentGroup;
    }

    private String currentGroup;

    public User getUser(String userName) {
        User user = userMap.get(userName);
        if (user == null) {
            user = new User(userName);
            userMap.put(userName, user);
        }
        return user;
    }
}
