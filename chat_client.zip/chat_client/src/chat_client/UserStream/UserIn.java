/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

import javax.crypto.SecretKey;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Receive and parse user commands.
 */
public class UserIn implements Runnable {
    private final BufferedReader in;
    private final int protocolLevel;
    private final Manager manager;

    public UserIn(BufferedReader in, Manager manager, Integer protocolLevel) {
        this.manager = manager;
        this.in = in;
        this.protocolLevel = protocolLevel;
    }

    @Override
    public void run() {
        try {
            while (true) {
                manager.checkConnected();
                String line = in.readLine();
                if (line == null) {
                    manager.quit();
                    break;
                }
                else if (line.length() != 0) {
                    if (line.charAt(0) != ':') manager.sendUserMsg(line);
                    else {
                        String cmd = line.substring(1).toUpperCase();
                        if (cmd.equals("Q")) {
                            manager.quit();
                            break;
                        }
                        else if (cmd.equals("US")) {
                            if (protocolLevel < 2) manager.protocolLevelLow();
                            else manager.queryUserList();
                        } else if (cmd.equals("GS")) {
                            if (protocolLevel < 2) manager.protocolLevelLow();
                            else manager.queryGroupList();
                        } else if (cmd.equals("C")) {
                            if (protocolLevel < 2) manager.protocolLevelLow();
                            else manager.setCurrentGroup(null);
                        } else {
                            final String[] sa = Main.splitUserCmd(line);
                            if (sa == null) manager.invalidUserCmd();
                            else {
                                cmd = sa[0].substring(1).toUpperCase();
                                if (cmd.equals("PM")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else {
                                        final String[] sa1 = Main.splitUserCmd(sa[1]);
                                        if (sa1 == null) manager.invalidUserCmd();
                                        else {
                                            final String recipientUserName = sa1[0];
                                            final String doc = sa1[1];
                                            manager.sendPrivate(recipientUserName, doc);
                                        }
                                    }
                                } else if (cmd.equals("C")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else manager.setCurrentGroup(sa[1]);
                                } else if (cmd.equals("GCREATE")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else manager.createGroup(sa[1]);
                                } else if (cmd.equals("GDISMISS")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else manager.dismissGroup(sa[1]);
                                } else if (cmd.equals("JOIN")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else manager.userJoinGroup(sa[1]);
                                } else if (cmd.equals("LEAVE")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else manager.userLeaveGroup(sa[1]);
                                } else if (cmd.equals("KICK")) {
                                    if (protocolLevel < 2) manager.protocolLevelLow();
                                    else {
                                        final String[] sa1 = Main.splitUserCmd(sa[1]);
                                        if (sa1 == null) manager.invalidUserCmd();
                                        else {
                                            final String groupName = sa1[0];
                                            final String userName = sa1[1];
                                            manager.kick(groupName, userName);
                                        }
                                    }
                                } else if (cmd.equals("KGEN")) {
                                    if (protocolLevel < 3) manager.protocolLevelLow();
                                    else manager.genKey(sa[1]);
                                } else if (cmd.equals("KASSIGN")) {
                                    if (protocolLevel < 3) manager.protocolLevelLow();
                                    else {
                                        final String[] sa1 = Main.splitUserCmd(sa[1]);
                                        if (sa1 == null) manager.invalidUserCmd();
                                        else {
                                            final String userName = sa1[0];
                                            final String keyString = sa1[1];
                                            SecretKey key = null;
                                            try {
                                                key = Crypto.stringToKey(keyString);
                                            } catch (IllegalArgumentException e) {}
                                            if (key == null) {
                                                manager.printlnUser("!encryption key must be"
                                                        + " a Base64-encoded list of 128 bits");
                                            } else manager.setKey(userName, key);
                                        }
                                    }
                                } else if (cmd.equals("KCLEAR")) {
                                    if (protocolLevel < 3) manager.protocolLevelLow();
                                    else manager.clearKey(sa[1]);
                                } else if (cmd.equals("FOFFER")) {
                                    if (protocolLevel < 3) manager.protocolLevelLow();
                                    else {
                                        final String[] sa1 = Main.splitMsg(sa[1]);
                                        if (sa1 == null) manager.invalidUserCmd();
                                        else {
                                            final String recipientUserName = sa1[0];
                                            final String pathString = sa1[1];
                                            try {
                                                final Path path = FileSystems.getDefault().getPath(pathString);
                                                if (!Files.isRegularFile(path)) {
                                                    manager.printlnUser("!this path does not refer to a regular file");
                                                } else {
                                                    try {
                                                        final long length = (Long) Files.getAttribute(path, "basic:size");
                                                        manager.offerFile(recipientUserName, path, length);
                                                    } catch (IOException e) {
                                                        manager.printlnUser("!cannot get file size");
                                                    }
                                                }
                                            } catch (InvalidPathException e) {
                                                manager.invalidUserPath();
                                            }
                                        }
                                    }
                                } else if (cmd.equals("FACCEPT")) {
                                    if (protocolLevel < 3) manager.protocolLevelLow();
                                    else {
                                        final String[] sa1 = Main.splitMsg(sa[1]);
                                        if (sa1 == null) manager.invalidUserCmd();
                                        else {
                                            final String senderUserName = sa1[0];
                                            final String pathString = sa1[1];
                                            try {
                                                final Path path = FileSystems.getDefault().getPath(pathString);
                                                try {
                                                    manager.acceptFile(senderUserName,
                                                            Files.newOutputStream(path,
                                                                    StandardOpenOption.CREATE,
                                                                    StandardOpenOption.WRITE,
                                                                    StandardOpenOption.TRUNCATE_EXISTING));
                                                } catch (IOException e) {
                                                    manager.printlnUser("!cannot open file");
                                                }
                                            } catch (InvalidPathException e) {
                                                manager.invalidUserPath();
                                            }
                                        }
                                    }
                                } else manager.invalidUserCmd();
                            }
                        }
                    }
                }
            }
        } catch (IOException | CryptoException e) {
            manager.printStackTrace(e);
        } catch (NoServerException e) {
        } finally {
            manager.close();
        }
    }
}
