/*
 *
 *  * ******************************************************
 *  *  * Copyright (C) 2020 Ruikang Xu: xuruikang6@hotmail.com
 *  *
 *  *  * permission of Ruikang Xu
 *  *  ******************************************************
 *
 */

package chat_client;

/**
 * Print messages to the user.
 */
public class UserOut {
    public void println(String s) {
        System.out.println(s);
    }

    public void invalidServerMsg(String msg) {
        println("!invalid server message: " + msg);
    }

    public void serverDisconnected() {
        println("!server disconnected");
    }

    public void serverError(String msg) {
        println("!server error: " + msg);
    }

    public void failDestroyKey() {
        println("!failed to securely erase existing key material");
    }

    public void transmissionIsGoing() {
        println("!did not change the key because the first part of the file did not arrive yet");
    }

    public void fileReceived(String senderUserName) {
        println("!file received from user \"" + senderUserName + "\"");
    }

    public void errorWritingFile() {
        println("!error writing file");
    }

    public void errorTransmission() {
        println("!error in transmitted file data");
    }

    public void printStackTrace(Throwable e) {
        e.printStackTrace(System.out);
    }
}
